
package hello.core.member;

/* 회원 서비스 구현체 */

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MemberServiceImpl implements MemberService {

    // Interface만 설정하면, NullPointException 에러가 발생한다.
    private final MemberRepository memberRepository; // Tip) Command + shift + Enter 누르면 세미콜론까지

    @Autowired  // → ac.getBean(MemberRepository.class) 처럼 동작한다고 생각
    public MemberServiceImpl(MemberRepository memberRepository) {
        this.memberRepository = memberRepository;
    }


    /*MemberServiceImpl의 작업 공간*/
    @Override
    public void join(Member member) {
        memberRepository.save(member);
    }

    @Override
    public Member findMember(Long memberId) {
        return memberRepository.findById(memberId);
    }


    //테스트 용도
    public MemberRepository getMemberRepository() {
        return memberRepository;
    }


}