package hello.core.member;

/* 회원등급 */
public enum Grade {
    BASIC,
    VIP
}
