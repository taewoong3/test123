package hello.core;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;

@Configuration
@ComponentScan (
        //basePackages = "hello.core.member",
        excludeFilters = @ComponentScan.Filter(type = FilterType.ANNOTATION, classes = Configuration.class)
)
public class AutoAppConfig {

}


/*
*  @ComponentScan = 해당 Annotation이 붙은 클래스들을 자동으로 스프링 빈에 등록해준다.
*   "classes = Configuration.class" = Configuration 어노테이션이 붙은 클래스는 제외한다는 의미(여기서는 예제 코드를 남기기 위해)
*   basePackages = "hello.core.member" = 설정한 패키지부터 하위 패키지로 찾기 때문에, member만 @Component의 대상이 된다.
*/