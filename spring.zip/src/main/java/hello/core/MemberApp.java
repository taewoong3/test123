package hello.core;

import hello.core.member.Grade;
import hello.core.member.Member;
import hello.core.member.MemberService;
import hello.core.member.MemberServiceImpl;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/* 회원 도메인 - 회원 가입 Main */
public class MemberApp {
    public static void main(String[] args) {    // psvm + 엔터치면 바로 main함수

//        AppConfig appConfig = new AppConfig();
//        MemberService memberService = appConfig.memberService();

        ApplicationContext applicationContext = new AnnotationConfigApplicationContext(AppConfig.class);
        MemberService memberService = applicationContext.getBean("memberService", MemberService.class);

        Member member = new Member(1L, "memberA", Grade.VIP);
        memberService.join(member);

        Member findMember = memberService.findMember(1L); // 🤩우선 memberService.findMember(1L) 만들고 option + command + v 하면 자료형 변수명을 한번에 지정할 수 있다.
        System.out.println("new member = " + member.getName()); // soupv 하면 변수까지 한번에
        System.out.println("find member = " + findMember.getName());

    }
}
