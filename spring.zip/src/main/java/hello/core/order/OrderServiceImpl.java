
package hello.core.order;

import hello.core.annotation.MainDiscountPolicy;
import hello.core.discount.DiscountPolicy;
import hello.core.discount.FixDiscountPolicy;
import hello.core.discount.RateDiscountPolicy;
import hello.core.member.Member;
import hello.core.member.MemberRepository;
import hello.core.member.MemoryMemberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/*
* 주문생성요청이오면,
*   회원정보를조회하고,
*   할인정책을적용한다음주문객체를생성해서반환한다.
* 메모리회원리포지토리와, 고정금액할인정책을구현체로생성
* */


@Component
// @RequiredArgsConstructor    // final이 붙은 필드를 보고 생성자를 자동으로 만들어준다.
public class OrderServiceImpl implements OrderService {

        // final이 붙은 필드는 '필수값' 이라는 의미
    private final MemberRepository memberRepository;         // 회원 찾기
    private final DiscountPolicy discountPolicy;


    // 수정자 자동 주입
    @Autowired
    public OrderServiceImpl(MemberRepository memberRepository, @MainDiscountPolicy DiscountPolicy discountPolicy) {
        this.memberRepository = memberRepository;
        this.discountPolicy = discountPolicy;
    }

    // @RequiredArgsConstructor로 인해서 해당 생성자를 자동으로 만들어준다.
    /*
    @Autowired // 생성자가 하나면 생략해도 적용 됨.
    public OrderServiceImpl(MemberRepository memberRepository, DiscountPolicy discountPolicy) {
        this.memberRepository = memberRepository;
        this.discountPolicy = discountPolicy;
    }
    */

    /* OrderServiceImpl 실행에만 집중 */
    @Override
    public Order createOrder(Long memberId, String itemName, int itemPrice) {
        Member member = memberRepository.findById(memberId); // 멤버 찾기
        int discountPrice = discountPolicy.discount(member, itemPrice);

        return new Order(memberId, itemName, itemPrice, discountPrice);
    }


    //테스트 용도
    public MemberRepository getMemberRepository() {
        return memberRepository;
    }

}